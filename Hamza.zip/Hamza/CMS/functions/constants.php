<?php 
$version = "1.0.0";
$name_company = "ATOUT SA";
$name_application = "AtoutProtect";
?>